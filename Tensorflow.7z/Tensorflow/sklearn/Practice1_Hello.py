# From: https://youtu.be/cKxRvEZd3Mw

from sklearn import tree
# Features:
    # Oranges Bumpy =1
    # Apples smooth = 0
# Lables:
    # Orange ==> 1   Oranes are heavier than Apples
    # Apples ==> 0

features = [[140,1], [130,1],[150,0],[170,0]]
labels = [0, 0, 1, 1]
clf = tree.DecisionTreeClassifier()
clf = clf.fit(features, labels)
print (clf.predict([[160,0]]))
