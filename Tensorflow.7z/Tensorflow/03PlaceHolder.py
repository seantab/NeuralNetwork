import tensorflow as tf
a = tf.placeholder(tf.float32)
b = tf.placeholder(tf.float32)

adder_node=a+b
sess= tf.Session()
File_Writer = tf.summary.FileWriter('D:\\Docs\\PycharmProjects\\Tensorflow\\graph', sess.graph)

print(sess.run(adder_node, {a:[1,3], b:[2,4]}))
