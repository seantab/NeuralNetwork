import tensorflow as tf
a= tf.constant(5)
b= tf.constant(2)
c= tf.constant(3)

d= tf.multiply(a,b)
e= tf.add(c,b)
f= tf.subtract(d,e)

sess = tf.Session()
File_Writer = tf.summary.FileWriter('D:\\Docs\\PycharmProjects\\Tensorflow\\graph', sess.graph)

outs = sess.run(f)

print(outs)
